# Medium Content-Type

This is just a mock post for checking the Medium content type

# Sections

***

# Markups Type

## Type 1 —Bold

**Bold text**

## Type 2 — Italic

*Italic text*

## Type 3 -Link or Mention

- **Link to [google](https://google.com)**

- **Mention** [Purna Satria Nugraha](medium.com/@purnasatria)

## Type 10 — Highlight / inline code

this is `highlight`

## Combination

***Bold-Italic***

***[Bold-Italic-Link](http://google.com)***

Other **Bold**-*Italic*-[Link](http://google.com)

***

# **Paragraph Type**

## Type 1 — Basic

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

## **Type 3— BigT**

# Lorem Ipsum

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

## Type 4 — Image

**Unsplash**

Layout 1

![](./assets/0143_0*Weh7zEeytpJZUY2Z)

*Photo by [Matthew Guay](https://unsplash.com/@maguay?utm_source=medium&utm_medium=referral) on [Unsplash](https://unsplash.com?utm_source=medium&utm_medium=referral)*


Layout 3

![](./assets/7929_0*Weh7zEeytpJZUY2Z)

*Photo by [Matthew Guay](https://unsplash.com/@maguay?utm_source=medium&utm_medium=referral) on [Unsplash](https://unsplash.com?utm_source=medium&utm_medium=referral)*


Layout 5

![](./assets/a758_0*Weh7zEeytpJZUY2Z)

*Photo by [Matthew Guay](https://unsplash.com/@maguay?utm_source=medium&utm_medium=referral) on [Unsplash](https://unsplash.com?utm_source=medium&utm_medium=referral)*


**Uploaded Image with alt text and caption**

![compass](./assets/9cb6_1*QQxkQqxrFvpPme-wBeW4rw.png)

*nauticalbytes*


**Clikable image without alt text, with caption**

![](./assets/c9ea_1*QQxkQqxrFvpPme-wBeW4rw.png)

*nauticalbytes*


## Type 6 — Quote

> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

## **Type 8 — Code Block**

**with language**

```go
package main

import "fmt"

func main() {
    fmt.Println("hello world")
}
```

**none**

```
text in code block
```

**auto**

```csharp
var x, y, z;  // Declare 3 variables
x = 5;    // Assign the value 5 to x
y = 6;    // Assign the value 6 to y
z = x + y;  // Assign the sum of x and y to z
```

## **Type 9 — Unordered list**

- item a

- item b

- item c

## Type 10 — Ordered list

1. point 1

2. point 2

3. point 3

## Type 11 — Embed

**Twitter**

<iframe src="https://cdn.embedly.com/widgets/media.html?type=text%2Fhtml&key=a19fcc184b9711e1b4764040d3dc5c07&schema=twitter&url=https%3A//twitter.com/medium/status/1462798035419869189&image=https%3A//i.embed.ly/1/image%3Furl%3Dhttps%253A%252F%252Fabs.twimg.com%252Ferrors%252Flogo46x38.png%26key%3Da19fcc184b9711e1b4764040d3dc5c07" width="500" height="281"></iframe>

[Original URL](https://twitter.com/Medium/status/1462798035419869189)

**Youtube**

<iframe src="https://cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2FAndRAyJg-W0%3Fstart%3D57%26feature%3Doembed%26start%3D57&display_name=YouTube&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DAndRAyJg-W0&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2FAndRAyJg-W0%2Fhqdefault.jpg&key=a19fcc184b9711e1b4764040d3dc5c07&type=text%2Fhtml&schema=youtube" width="854" height="480"></iframe>

[Original URL](https://www.youtube.com/watch?v=AndRAyJg-W0&t=57s)

**Github Gist**

```text
1. How do I submit an issue?
 - Sign up for a contest at https://app.sherlock.xyz/audits/contests
 - Upon successful signup, a personal repo will be created for you
 - In your personal repo, go to the "Issues" tab
 - Click "New Issue"
 - Click "Get Started" (in the "Audit Item" section)
 - You can title the issue whatever you want
 - Fill out the fields in the body of the issue
 - Add a label for the severity of the issue (High/Med/etc.)
 - Click "Submit New Issue"
 - Congrats, that's it! You've submitted your first issue!

Note: If you reference code from the codebase in your issue, please permalink it. 
If you write code related to PoC, you can write it inline. 
The permalinking is to prevent attempts to trick the judges by altering source code to make it look like an exploit exists where it doesn't
```
[Original URL](https://gist.github.com/kanthgithub/7fe23b6cd96ba10cb50583b571f322df)


**Some links**

[https://google.com](https://google.com)

## Type 13 — SmalT

## Lorem ipsum

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

# Others

weird indenting text

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

emoji 👏

superscript ¹⁰⁸ log²

multiline list

- Item 1
Description 1

- Item 2
Description 2

1. Point 1
Description 1

2. Point 2
Description 2